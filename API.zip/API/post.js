const axios = require('axios')
const url = "https://jsonplaceholder.typicode.com/posts"

// Lista de dados para envio a API
const insertPost = {
    userId: 2,
    id: 2,
    title: "Senhor dos Anéis",
    body: "Livro de fantasia e aventura",
    completed: true
}

// Requisição POST para criar novo recurso na API
axios.post(url, insertPost)
    .then(response => {
        console.log("Recurso criado com sucesso: ")
        console.log(response.data)
    })
    .catch(error =>{
        // Tratamento de execução
        console.log(`Erro no Post da API: ${error}`)
    })
const axios = require('axios')
const url = "https://jsonplaceholder.typicode.com/posts/1"

// Atualização de dados com o método PUT
const put = {
    title: 'De Volta para o Futuro',
    body: 'Filme de ficção científica',
    completed: true,
    userId: 1
}

// Envio de dados atualizados
axios.put(url, put)
    .then(response => {
        console.log("Dado atualizado com sucesso")
        console.log(response.data)
    })
    .catch(error => {
        // Tratamento de exceção
        console.log(`Erro no update de dados: ${error}`)
    })
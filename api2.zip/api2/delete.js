const axios = require('axios')
const url = "https://jsonplaceholder.typicode.com/posts/1"

// const exclusaoDados = {
//     id: 1,
//     userId: 1
// }

axios.delete(url)
    .then(response => {
        console.log("Elemento excluído")
        console.log(`Status de resposta: ${response.status}`)
    })
    .catch(error => {
        console.log(`Erro ao tentar excluir um dado: ${error}`);
    })
const axios = require('axios')
const url = "https://jsonplaceholder.typicode.com/todos/1"

// Requisição GET

axios.get(url)
    .then(response =>{
        // Dados recebidos da API        
        console.log("Dados recebidos da API: ")
        console.log(response.data)
    })
    .catch(error =>{
        // Tratamento de erro, caso não execute a API
        console.log(`Erro ao acessar a API: ${error}`)
    })
